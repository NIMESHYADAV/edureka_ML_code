import os
# Syntax: os.rename(old_name, new_name)

os.rename('/Users/gyanendrakumar/PycharmProjects/Edureka_DS/Module_2/File_handling/nimesh.txt',
          '/Users/gyanendrakumar/PycharmProjects/Edureka_DS/Module_2/File_handling/ravi.txt')