values=input()
l=values.split(",")
t=tuple(l)
print(l)
print(t)

