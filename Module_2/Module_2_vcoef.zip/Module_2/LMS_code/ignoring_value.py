# _, predicted = outputs.max(1)
for _ in range(5):
    print("hello")

# to ignore a value we use _ underscore.
