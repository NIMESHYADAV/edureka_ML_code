a = [1, 2, 3, 4]

# list comprehension is used to create another list from an existing list
# [function (for loop) (optional: condition for filtering)]
# square of original list
b = [elem**2 for elem in a if elem > 2]
print(b)


"""
nested loop in list comprehension

matrix = [[1,2,3], [4,5,6], [7,8,9]]

flat = [n for row in matrix for n in row]
print(flat)
# 3 things
# [function loop condition/filtering]

# below code would give same  O/P as above list comprehension 
flat = []
for row in matrix:
    for n in row:
        flat.append(n)
print(flat)
"""