# list[start:stop:step]
a = [11, 12, 13, 14, 15]
# print(a[0:5:2])

# how to reverse a list
b = a[::-1]
print(b)


