a = [11, 12, 13, 14, 15]
a[:3]  # when start index is missing then it would start from 0
a[1:]  # when stop index is missing then it would fetch values till the end
a[1:5:-1]  # No data

a[5:1:-1]
print(a[::-1])

# if we have list inside a tuple, can we modify
# if want to reverse from 2nd rigtmost  then ?
a = [1, 2, 3, 4]
