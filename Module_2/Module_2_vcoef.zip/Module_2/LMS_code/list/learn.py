# How to take input in dictionary using input()?
d = {}

while 1:
    key = eval(input("enter the key:"))
    value = eval(input("enter a value"))
    d[key] = value
    print("current state:")
    print(d)
    val = int(input("enter 1 to exit or 0 to continue "))
    if val == 1:
        break

