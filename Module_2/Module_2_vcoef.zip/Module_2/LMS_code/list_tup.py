list=["Hadoop","Python","Android"]
print(list)

tuple=("Python","Hadoop")
print(tuple)