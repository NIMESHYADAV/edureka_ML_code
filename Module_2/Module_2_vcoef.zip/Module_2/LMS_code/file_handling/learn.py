import io
fo = open('myfile.txt')
print(fo.tell())
fo.seek(0, io.SEEK_END)
print(fo.tell())
print(fo.read())
