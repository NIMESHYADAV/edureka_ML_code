# fo = open('neha.txt')
#
# fo.close()
n = eval(input("which line do you want to read:"))

with open('neha.txt') as fo:
    line = 1
    for data in fo:
        if line == n:
            print(data)
            break
        line += 1  # line = line + 1

# Are these two functions used only when the file is open?