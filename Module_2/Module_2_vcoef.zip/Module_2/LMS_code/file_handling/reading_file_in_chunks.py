# when file is bigger then it is efficient to read it in chunks

file_obj = open('hello.txt')

while 1:
    data = file_obj.read(3)
    if data:
        print(data)
    else:
        break

file_obj.close()