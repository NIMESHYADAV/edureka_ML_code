
# reading a file
path = '/Users/gyanendra/Desktop/PyDataScience_venv/Module2/hello.txt'
file_obj = open(path, 'r')

# M1: reading full file in single shot
# print(file_obj.read())

# M2: reading line by line
# for elem in file_obj:
#     print(elem)

# M3: reading line (single)
print(file_obj.readline())
print(file_obj.readline())
print(file_obj.readline())

# M4: reading file in chunks(refer another file)

