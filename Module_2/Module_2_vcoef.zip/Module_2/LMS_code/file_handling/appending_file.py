fo = open('mylog.txt', 'a')
fo.write("OSError"+'\n')
fo.close()
