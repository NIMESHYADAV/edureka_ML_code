file_obj = open('hello.txt', 'w')

# write to a file
for elem in range(10):
    file_obj.write("Python "+str(elem)+'\n')
file_obj.close()
