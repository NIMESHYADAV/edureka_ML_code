fo = open('mylog.txt', 'a')
fo.write("OSError"+'\n')
fo.close()

# 1
print(fo.closed)

# 2: mode in which you have opened the file
print(fo.mode)

# 3: file name
print(fo.name)


