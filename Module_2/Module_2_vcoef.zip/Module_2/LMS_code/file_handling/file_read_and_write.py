fo = open('myfile.txt', 'w+')
# write will move the file pointer to the end after writing the data
fo.write("welcome to the course")

# to read the data we need to move the file pointer back
fo.seek(0)
#fo.seek(3,0)
print(fo.read())
fo.close()