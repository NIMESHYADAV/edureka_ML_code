"""
dict value can be any data type
only immutable value can be dict keys.
1. numbers
2. strings
3. tuples
4. Any other object that is immutable
"""
d = {2: [1, 2], 3: 'hello', 5: 34}
# for key, val in d.items():
#     print(key, val)
#
# # only values
# for val in d.values():
#     print(val)

# only keys
for key in d.keys():
    print(key)