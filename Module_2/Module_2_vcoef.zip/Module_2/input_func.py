age = input("enter your age:")
print(age)
print(type(age))

# to retrieve the original value
# NOTE: don't use eval when the entered value is a string
original_val = eval(age)
print(type(original_val))