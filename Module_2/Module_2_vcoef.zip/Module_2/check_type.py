age = eval(input("enter your age:"))
print(age)
print(type(age))

# checking the type of entered value
if isinstance(age, int):
    if age >= 18:
        print("You can cast your Vote")
    else:
        print("You are not allowed to cast your Vote")
else:
    print("Invalid value: entered value is not an integer")
"""
when i try to check the type of an variable.I see the <type 'str'> in the console, 
where your console prints <class >
"""