# 1: full import
import math
print(math.sqrt(9))

# 2: specific import
from math import sqrt
print(sqrt(4))  # debugging is difficult as library name is missing

# 3
# it imports full module and you don't have to use the module name
from math import *
sqrt(5)
#acos()

# 4: alias
import math as mth
mth.sqrt(4)