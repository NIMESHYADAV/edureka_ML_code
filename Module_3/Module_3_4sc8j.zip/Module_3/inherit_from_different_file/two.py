from one import A

class B(A):
    pass

obj = B()
obj.method()

#  Is it necessary that the two different files should be in the
# same directory to access methods

import sys

sys.path.append("directory_name")
print(sys.path)
