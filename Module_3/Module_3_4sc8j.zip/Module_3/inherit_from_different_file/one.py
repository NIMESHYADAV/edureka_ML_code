class A:
    def method(self):
        print("python rocks")