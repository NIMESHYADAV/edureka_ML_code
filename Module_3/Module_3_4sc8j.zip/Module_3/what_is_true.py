if [1]:
    print("IF")
else:
    print("Else")

"""
True: True, any non-zero, non-empty values
False: False, 0, None, '', [], (), {} or any empty object
"""