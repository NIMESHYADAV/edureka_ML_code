# user-defined functions
# definition
def hello(a, b):
    c = a + b
    return c


# function calling
output = hello(100, 200)
print(output)
"""
if return statement is present in the function definition then that value
would be returned
2. when return statement is not present in the function definition,
then 'None' value would be returned by default.
"""

# But when you entered it initially, the values were output