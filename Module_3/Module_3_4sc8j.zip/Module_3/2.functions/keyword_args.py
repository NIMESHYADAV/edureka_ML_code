def func(age, name, gender):
    print(age)
    print(name)
    print(gender)


func(gender='NA', age=28, name='python')