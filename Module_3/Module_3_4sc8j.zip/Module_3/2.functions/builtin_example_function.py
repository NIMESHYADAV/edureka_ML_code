# all(sequence) means AND
# True : non zero, non empty values, : -1, 1, 100, "hello", True, [1,2]
# False: False, 0, '', [], {}, (),None or any empty pbject
#print(all([1, 2, "hello", -1]))
########################

# # any(sequence) means OR
# print(any([0, '', None, [], (), {}]))
# print(any([1, '', None, [], (), {}]))


#########################
# # chr(code_str)
# print(chr(65)) # unicode code point
# print(chr(45))
############################
# # ord(character) returns the code point for the passed character.
# print(ord('-'))
###############################

# # enumerate(sequence)
# a = [100, 200, 300, 400, 500]
# # for elem in a:
# #     print(elem)
# for elem in enumerate(a):
#     print(elem)
################################
# # globals()
# a = 100
# b = [1,2]
# print(globals())

#############################
# # sum(iterable)
# print(sum([11, 12, 13]))
# print(sum((11, 12, 13)))
###########################
# reversed(sequence)
a = [1,2,3,4]

print(reversed(a))

print(list(reversed(a)))
print(a[::-1])
for elem in reversed(a):
    print(elem)
# zip(sequence, sequence)
# a = [11 , 12 ,23, 100, 200 ]
# b = [ 1 , 3 , 6]
# # # How to add a[0 ] and b[0] ?
# # output = []
# # for elem in zip(a,b):
# #     output.append(elem[0] + elem[1])
# # print(output)
# print(list(zip(a,b)))
