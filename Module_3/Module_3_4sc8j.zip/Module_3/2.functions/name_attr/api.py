# what is __name__ == '__main__'

# sumit's code
a = 100
def square(a):
    print(a**2)


def cube(i):
    print(i**3)



print(__name__)
# using the APIs
if __name__ == '__main__':
    square(12)
    cube(10)





