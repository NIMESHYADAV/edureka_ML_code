import random

# 1. randrange()
#print(random.randrange(100))
print(random.randrange(1,5))

# 2. randint(start, stop)
# Return random integer in range [start, stop], including both end points.
#print(random.randint(1, 5))

# 3. uniform()
print(random.uniform(2,6))