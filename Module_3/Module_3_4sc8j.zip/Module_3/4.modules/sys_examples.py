import sys
"""
age = eval(input("enter your age:"))

if not isinstance(age, int):
    print("entered age is not an integer")
    sys.exit()  # terminates the program execution

print("Bingoo")
"""
for elem in dir(sys):
    print(elem)
print(sys.version)
print(sys.maxsize)  #max size number python can work with
print(sys.builtin_module_names)
