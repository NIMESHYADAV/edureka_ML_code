import math
# 1. ceil() returns the ceiling of a number
print(math.ceil(10.01))
print(math.ceil(-10.01))
print(math.ceil(10))

# 2. copysign(x,y) returns x with the sign of y
print(math.copysign(10, -1))

# 3. fabs() returns absolute value , i.e ignores the sign
print(math.fabs(-20))

# 4. exp
print(math.exp(2))

# 5. expm1
print(math.expm1(2))

# 6. log
print(math.log(10, 10))