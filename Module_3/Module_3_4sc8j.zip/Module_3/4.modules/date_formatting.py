# https://docs.python.org/2/library/datetime.html
# section :8.1.7. strftime() and strptime()
import datetime
mydate = datetime.datetime.today()

print(mydate) # this is datetime object
print(mydate.strftime("%Y/%B/%A"))  # this is a string
print(mydate.strftime("%Y %B %A"))  # this is a string

# REST

# strptime() used to convert date from a string to datetime.datetime object