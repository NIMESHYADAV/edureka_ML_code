import os

print(os.getcwd())
#print(os.mkdir('/Users/gyanendra/Desktop/PyDataScience_venv/Module3/modules/os_ex/hello'))
#os.rmdir('/Users/gyanendra/Desktop/PyDataScience_venv/Module3/modules/os_ex/hello')
print(os.name)
print(os.environ)
print(os.getlogin())
