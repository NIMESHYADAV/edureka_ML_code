def func(a, b):
    a.append(6)
    b = [4, 5]
    print(a)
    print(b)
i = [1, 2 ]
j= [ 3, 4 ]
func(i, j)
print(i)
print(j)