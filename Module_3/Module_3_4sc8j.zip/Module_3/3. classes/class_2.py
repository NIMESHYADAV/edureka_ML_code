class Edureka:
    """
    this is a edureka class
    and this is our first class
    """
    a = 100 # class variable
    def method(self):
        print("I am method")


# built-in attributes
print(Edureka.__dict__)
print(Edureka.__doc__)
print(Edureka.__name__)
print(Edureka.__module__)
print(Edureka.__bases__)


