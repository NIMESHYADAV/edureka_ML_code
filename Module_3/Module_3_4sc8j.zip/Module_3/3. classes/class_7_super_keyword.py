"""
if parent and child both contain __init__ methods then if you instantiate the child class then
parent class init method won't be called automatically therefore with the help of super keyword( or
also the other syntax) you would have to explicitly call the parent class init.
"""


class A:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def hello(self):
        print("AA")


class B(A):
    def __init__(self, c, d):
        super(B, self).__init__(10, 20)  # syntax 1 to call parent class method
        #A.__init__(self, c+10, d+10)      # syntax 2 to call parent class method
        # super().__init__(10, 20)         # syntax 3 to call parent class method
        self.c = c
        self.d = d

    def bye(self):
        super(B, self).hello()  # calling parent class method
        print("BBBB")


b = B(1, 2)
print(b.a)
b.bye()
