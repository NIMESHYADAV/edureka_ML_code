import api


api.square(30)
print(api.a)