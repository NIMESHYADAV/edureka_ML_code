def func(age, name, gender):
    print(age)
    print(name)
    print(gender)


# calling using positional args
func(21, 'Ravi', 'Mz')