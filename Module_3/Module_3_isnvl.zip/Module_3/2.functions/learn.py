# variable length args


def add(*args, **kwargs):
    """
    :param args: capture all the positional(required) arguments
    and stores in a tuple.
    :param kwargs: capture all the keyword(non-positional) arguments
    and stores in a dictionary
    """
    print("Positional args:", args)  # as a tuple
    print("keyword args:", kwargs)   # as a dict
    #Method 2:
    print(sum(args) + sum(list(kwargs.values())))
    print("#" * 20)


###### client code /api user ##
add()
add(1, 2)
add(1, 2, 3, a=12, b=13)
"""
wouldn't that depend on the function expression? so if the expre ssion 
contains an operation that is not condusive to a given data type, it will throw an error?
"""


