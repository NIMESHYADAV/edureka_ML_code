def func(a):
    return a**3



def add(a, b):
    return a + b

if __name__ == '__main__':
    print("First")
    out = add(1,2)
    print(out)
    print(func(10))
    print("End")

# With out __name__=='__main__' also it
# starts from the print('frist) what is the need of the main and where its used


