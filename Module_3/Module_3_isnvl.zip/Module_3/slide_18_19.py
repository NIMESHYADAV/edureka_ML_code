# 1.sorted()
# a = ['e', 'd', 'u', 'r', 'e', 'k', 'a']
#
# print(sorted(a))

# a = [[11, 2], [3, -4], [5,-6]]
# # sorting nested list
# from operator import itemgetter
# print(sorted(a, key=itemgetter(0)))
# print(sorted(a, key=itemgetter(1)))

# 2.all()
# a = [1, 100, 1]
# print(all(a))

# 3. any() :if even a single element is True(non-zero, non-empty) then O/P: true
# a = [0, None, '', [], (), {}]
# print(any(a))  # False
#
# a = [0, -1, '', [], (), {}]
# print(any(a))  # True

# 4. bool(): returns boolean value
# print(bool(-1))
# print(bool(0))
# print(bool([12]))
#
# 5. chr(code_point or ASCIIvalue)
# print(chr(97))
# to get a code_point or ASCII value use ord()
# print(ord('A'))
#
# # 6. abs: ignores the sign
# print(abs(-100))

# # 7. globals()
# a = 100
# print(globals())

# 8: eval() : evaluate the expression within a string

# print(eval("2>3"))
# print(eval("11"))

# # 9. int()
# print(int("234"))
# print(int("hello"))  # wrong


