"how do we use parent class method after overriding it in child class"

class Edureka:
    def hello(self):
        return "HELLO"

    def hi(self):
        return "hi"


class Student(Edureka):
    def bye(self):
        print("hello")

    def hello(self):
        #output = Edureka.hello(self)
        output = super().hi()
        print(output +" Bingooo")

        # super(B, self).__init__(10, 20)  # syntax 1 to call parent class method
        # #A.__init__(self, c+10, d+10)      # syntax 2 to call parent class method
        # # super().__init__(10, 20)         # syntax 3 to call parent class method

obj = Student()
obj.hello()