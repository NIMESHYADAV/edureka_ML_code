a = [10, 20, 30]

# enumerate returns [(index, value), (index, value)....]
print("list")
for elem in enumerate(a):
    print(elem)

print("Tuple")
tup = (11, 12, 13)
for elem in enumerate(tup):
    print(elem)

print("Dictionary")
my_dict = {1: 11, 2: 22, 3: 33}
for elem in enumerate(my_dict):
    print(elem[1])
for _, value in enumerate(my_dict):
    print(value)

# in enumerate function ,can we displays only value will that work ?