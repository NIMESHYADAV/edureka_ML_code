import json
d = {1: 11, 2: 22}
print(type(d))

a = json.dumps(d)
print(type(a))
print(a)

# get the data back
b = json.loads(a)
print(type(b))
print(b)
