import os

# join the paths
print(os.path.join('hello/bye', 'hi/how', 'yes/no'))

# path from the root(absolute path)
print(os.path.abspath('hello'))

# check the path whether it is valid or not

print(os.path.exists('/hello/bye'))

print(os.path.split('/Users/gyanendra/Desktop/PyDataScience_venv/Module3/date_formatting.py'))

print(os.path.isdir('/Users/gyanendra/Desktop/PyDataScience_venv/Module3/anurag.py'))

