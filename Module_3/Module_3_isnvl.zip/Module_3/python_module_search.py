import sys
for elem in sys.path:
    print(elem)

#sys.path.append('your module path')
