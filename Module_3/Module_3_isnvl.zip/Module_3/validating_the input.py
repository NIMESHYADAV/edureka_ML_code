"""

If I ask for user input and an invalid parameter is
passed. How do i set the cursor
focus back to prompt user to enter new value in python?
"""
# user must enter a number

while 1:
    val = eval(input("enter a number "))
    if isinstance(val, int):
        print("Whoot, you gave valid value")
        break
    print("value entered is of wrong type: ", type(val))

