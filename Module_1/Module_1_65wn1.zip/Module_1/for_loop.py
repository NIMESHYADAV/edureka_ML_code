# for loop is used to iterate over a sequence

mylist = [1, 2, 100, 200, -1, -5]

for i in mylist:
    print(i+100)
    print("Howdy")

#
for i in "edureka":
    print(i)



