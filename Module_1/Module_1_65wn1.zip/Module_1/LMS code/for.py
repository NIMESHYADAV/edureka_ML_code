fruits=['Banana','Apple','Grapes']

for index in range(len(fruits)):
    print(fruits[index])


#Example

list1=[1,2,3,"Python"]

for i in list1:
    print(i)