for i in range(10,50):
    print(i)
    if(i==30):
        break

for j in range(1,11):
    if(j==5):
        continue
    print(j)



for k in range(1,3):
    pass
print("Loop ends here")