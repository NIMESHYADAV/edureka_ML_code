A='Welcome To edureka!'

B="Python is Great"

print(A)

print(B)
