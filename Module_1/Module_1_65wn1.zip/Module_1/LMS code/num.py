A=10

B=10.65

C=10+6j

print(A,B,C)

