import sys
sys.path.append(r'/Users/gyanendrakumar/PycharmProjects/Edureka_DS/bibha_module')



import mymodule as mm
obj = mm.Edureka()
print(obj.api(4))