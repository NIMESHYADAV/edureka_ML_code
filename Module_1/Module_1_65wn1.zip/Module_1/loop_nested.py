# nested loop means:loop inside another loop

for i in "Edureka":
    for j in "Rocks":
        print(i, j)
# O(n^2)
