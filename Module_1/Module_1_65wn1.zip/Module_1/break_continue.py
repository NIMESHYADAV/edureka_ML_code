# break and continue
# it can only be used in loop.

for i in range(10):
    if i == 4:
        #break
        continue
    print(i)

print("this is outside the for loop")